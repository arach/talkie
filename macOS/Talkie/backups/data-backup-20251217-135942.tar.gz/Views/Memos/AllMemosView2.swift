//
//  AllMemosView2.swift
//  Talkie
//
//  Rebuilt All Memos view - clean, performant, ViewModel-driven
//  Uses GRDB repository with proper pagination
//

import SwiftUI

// MARK: - All Memos View 2.0

struct AllMemosView2: View {
    @StateObject private var viewModel = MemosViewModel()
    @State private var selectedMemoIDs: Set<UUID> = []
    @State private var searchText = ""

    // Debounce search
    @State private var searchTask: Task<Void, Never>?

    var body: some View {
        VStack(spacing: 0) {
            // Header with search and sort controls
            headerView

            // Memos table
            if viewModel.isLoading && viewModel.memos.isEmpty {
                loadingView
            } else if viewModel.memos.isEmpty {
                emptyView
            } else {
                memosTable
            }

            // Footer with stats
            footerView
        }
        .task {
            await viewModel.loadMemos()
        }
        .onChange(of: searchText) { _, newValue in
            // Debounce search (500ms)
            searchTask?.cancel()
            searchTask = Task {
                try? await Task.sleep(for: .milliseconds(500))
                if !Task.isCancelled {
                    await viewModel.search(query: newValue)
                }
            }
        }
    }

    // MARK: - Header

    private var headerView: some View {
        HStack(spacing: Spacing.md) {
            // Search
            HStack(spacing: 6) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(TalkieTheme.textMuted)
                    .font(.system(size: 12))

                TextField("Search memos...", text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 13))

                if !searchText.isEmpty {
                    Button(action: { searchText = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(TalkieTheme.textMuted)
                            .font(.system(size: 12))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, Spacing.sm)
            .padding(.vertical, 6)
            .background(TalkieTheme.surfaceCard)
            .cornerRadius(CornerRadius.sm)

            Spacer()

            // Sort controls
            sortControls
        }
        .padding(Spacing.md)
        .background(TalkieTheme.surfaceElevated)
        .overlay(
            Rectangle()
                .fill(TalkieTheme.border)
                .frame(height: 1),
            alignment: .bottom
        )
    }

    private var sortControls: some View {
        HStack(spacing: 8) {
            Text("Sort:")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(TalkieTheme.textMuted)

            ForEach([MemoSortField.timestamp, .title, .duration, .workflows], id: \.self) { field in
                sortButton(for: field)
            }
        }
    }

    private func sortButton(for field: MemoSortField) -> some View {
        Button(action: {
            Task {
                await viewModel.changeSortField(field)
            }
        }) {
            HStack(spacing: 4) {
                Text(field.displayName)
                    .font(.system(size: 11, weight: .medium))

                if viewModel.sortField == field {
                    Image(systemName: viewModel.sortAscending ? "chevron.up" : "chevron.down")
                        .font(.system(size: 9, weight: .semibold))
                }
            }
            .foregroundColor(viewModel.sortField == field ? TalkieTheme.textPrimary : TalkieTheme.textMuted)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 4)
                    .fill(viewModel.sortField == field ? TalkieTheme.surfaceCard : Color.clear)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Memos Table

    private var memosTable: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(viewModel.memos) { memo in
                        MemoRow2(
                            memo: memo,
                            isSelected: selectedMemoIDs.contains(memo.id)
                        )
                        .onTapGesture {
                            toggleSelection(memo.id)
                        }
                        .onAppear {
                            // Load more when approaching end
                            if memo.id == viewModel.memos.last?.id {
                                Task {
                                    await viewModel.loadNextPage()
                                }
                            }
                        }
                    }

                    // Loading indicator for pagination
                    if viewModel.isLoading && !viewModel.memos.isEmpty {
                        HStack {
                            ProgressView()
                                .scaleEffect(0.7)
                            Text("Loading more...")
                                .font(.system(size: 11))
                                .foregroundColor(TalkieTheme.textMuted)
                        }
                        .padding(.vertical, Spacing.md)
                    }
                }
            }
        }
    }

    // MARK: - Empty/Loading States

    private var loadingView: some View {
        VStack(spacing: Spacing.md) {
            ProgressView()
            Text("Loading memos...")
                .font(.system(size: 13))
                .foregroundColor(TalkieTheme.textMuted)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyView: some View {
        VStack(spacing: Spacing.md) {
            Image(systemName: "mic.slash")
                .font(.system(size: 48))
                .foregroundColor(TalkieTheme.textMuted)

            if searchText.isEmpty {
                Text("No memos yet")
                    .font(.system(size: 15, weight: .medium))
                Text("Record your first voice memo to get started")
                    .font(.system(size: 13))
                    .foregroundColor(TalkieTheme.textMuted)
            } else {
                Text("No results for \"\(searchText)\"")
                    .font(.system(size: 15, weight: .medium))
                Text("Try a different search term")
                    .font(.system(size: 13))
                    .foregroundColor(TalkieTheme.textMuted)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // MARK: - Footer

    private var footerView: some View {
        HStack {
            Text("\(viewModel.displayedCount) of \(viewModel.totalCount) memos")
                .font(.system(size: 11))
                .foregroundColor(TalkieTheme.textMuted)

            Spacer()

            if viewModel.hasMorePages {
                Button("Load More") {
                    Task {
                        await viewModel.loadNextPage()
                    }
                }
                .font(.system(size: 11, weight: .medium))
                .disabled(viewModel.isLoading)
            }
        }
        .padding(Spacing.sm)
        .background(TalkieTheme.surfaceElevated)
        .overlay(
            Rectangle()
                .fill(TalkieTheme.border)
                .frame(height: 1),
            alignment: .top
        )
    }

    // MARK: - Helpers

    private func toggleSelection(_ id: UUID) {
        if selectedMemoIDs.contains(id) {
            selectedMemoIDs.remove(id)
        } else {
            selectedMemoIDs.insert(id)
        }
    }
}

// MARK: - Memo Row 2.0 (Lightweight, Only Observes Displayed Properties)

struct MemoRow2: View {
    let memo: VoiceMemo
    let isSelected: Bool

    var body: some View {
        HStack(spacing: Spacing.md) {
            // Selection indicator
            Circle()
                .fill(isSelected ? Color.accentColor : Color.clear)
                .frame(width: 8, height: 8)
                .overlay(
                    Circle()
                        .strokeBorder(TalkieTheme.border, lineWidth: 1)
                )

            VStack(alignment: .leading, spacing: 4) {
                // Title
                Text(memo.displayTitle)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(TalkieTheme.textPrimary)
                    .lineLimit(1)

                // Metadata
                HStack(spacing: 8) {
                    // Timestamp
                    Text(MemosViewModel.timestampFormatter.string(from: memo.createdAt))
                        .font(.system(size: 11))
                        .foregroundColor(TalkieTheme.textMuted)

                    Text("•")
                        .foregroundColor(TalkieTheme.textMuted)

                    // Duration
                    HStack(spacing: 3) {
                        Image(systemName: "waveform")
                            .font(.system(size: 9))
                        Text(MemosViewModel.formatDuration(memo.duration))
                            .font(.system(size: 11))
                    }
                    .foregroundColor(TalkieTheme.textMuted)

                    // Source badge
                    if memo.source != .unknown {
                        MemoSourceBadge(source: memo.source, showLabel: false, size: .small)
                    }
                }
            }

            Spacer()

            // Word count
            if memo.wordCount > 0 {
                Text("\(memo.wordCount) words")
                    .font(.system(size: 11))
                    .foregroundColor(TalkieTheme.textMuted)
            }
        }
        .padding(.horizontal, Spacing.md)
        .padding(.vertical, Spacing.sm)
        .background(isSelected ? TalkieTheme.surfaceCard.opacity(0.5) : Color.clear)
        .overlay(
            Rectangle()
                .fill(TalkieTheme.border)
                .frame(height: 1),
            alignment: .bottom
        )
    }
}

// MARK: - Sort Field Display Name

extension MemoSortField {
    var displayName: String {
        switch self {
        case .timestamp: return "Date"
        case .title: return "Title"
        case .duration: return "Duration"
        case .workflows: return "Workflows"
        }
    }
}

// MARK: - MemoSourceBadge View

struct MemoSourceBadge: View {
    let source: MemoSource
    var showLabel: Bool = true
    var size: BadgeSize = .small

    enum BadgeSize {
        case small, medium

        var iconSize: CGFloat {
            switch self {
            case .small: return 9
            case .medium: return 11
            }
        }

        var fontSize: CGFloat {
            switch self {
            case .small: return 8
            case .medium: return 9
            }
        }

        var padding: CGFloat {
            switch self {
            case .small: return 4
            case .medium: return 6
            }
        }
    }

    var body: some View {
        HStack(spacing: 3) {
            Image(systemName: source.icon)
                .font(.system(size: size.iconSize))

            if showLabel {
                Text(source.displayName)
                    .font(.system(size: size.fontSize, weight: .medium, design: .monospaced))
            }
        }
        .foregroundColor(source.color)
        .padding(.horizontal, size.padding)
        .padding(.vertical, 2)
        .background(source.color.opacity(0.12))
        .cornerRadius(4)
    }
}

// MARK: - Preview

#Preview {
    AllMemosView2()
        .frame(width: 800, height: 600)
}
