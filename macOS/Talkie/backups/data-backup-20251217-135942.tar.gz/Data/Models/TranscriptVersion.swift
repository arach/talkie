//
//  TranscriptVersion.swift
//  Talkie
//
//  Pure Swift model for transcript versions
//

import Foundation
import GRDB

// MARK: - Transcript Version Model

struct TranscriptVersion: Identifiable, Codable, Hashable {
    let id: UUID
    let memoId: UUID
    var version: Int
    var content: String
    var sourceType: String  // "system_ios", "system_macos", "user"
    var engine: String?     // "whisper_kit", "parakeet", etc.
    var createdAt: Date
    var transcriptionDurationMs: Int64

    init(
        id: UUID = UUID(),
        memoId: UUID,
        version: Int,
        content: String,
        sourceType: String,
        engine: String? = nil,
        createdAt: Date = Date(),
        transcriptionDurationMs: Int64 = 0
    ) {
        self.id = id
        self.memoId = memoId
        self.version = version
        self.content = content
        self.sourceType = sourceType
        self.engine = engine
        self.createdAt = createdAt
        self.transcriptionDurationMs = transcriptionDurationMs
    }
}

// MARK: - GRDB Record

extension TranscriptVersion: FetchableRecord, PersistableRecord {
    static let databaseTableName = "transcript_versions"

    enum Columns {
        static let id = Column(CodingKeys.id)
        static let memoId = Column(CodingKeys.memoId)
        static let version = Column(CodingKeys.version)
        static let content = Column(CodingKeys.content)
        static let sourceType = Column(CodingKeys.sourceType)
        static let engine = Column(CodingKeys.engine)
        static let createdAt = Column(CodingKeys.createdAt)
        static let transcriptionDurationMs = Column(CodingKeys.transcriptionDurationMs)
    }

    /// Association back to memo
    static let memo = belongsTo(VoiceMemo.self)
}

// MARK: - Computed Properties

extension TranscriptVersion {
    var sourceTypeEnum: TranscriptSourceType? {
        TranscriptSourceType(rawValue: sourceType)
    }

    var engineDisplayName: String {
        TranscriptEngines.displayName(for: engine)
    }

    var sourceDescription: String {
        var parts: [String] = []

        if let source = sourceTypeEnum {
            parts.append(source.displayName)
        }

        let engineName = engineDisplayName
        if !engineName.isEmpty {
            parts.append(engineName)
        }

        return parts.isEmpty ? "Unknown" : parts.joined(separator: " · ")
    }
}

// MARK: - Sendable Conformance

extension TranscriptVersion: Sendable {}

// MARK: - Supporting Types

enum TranscriptSourceType: String, Codable {
    case systemIOS = "system_ios"
    case systemMacOS = "system_macos"
    case user = "user"

    var displayName: String {
        switch self {
        case .systemIOS: return "iOS"
        case .systemMacOS: return "macOS"
        case .user: return "Edited"
        }
    }
}

struct TranscriptEngines {
    static let appleSpeech = "apple_speech"
    static let whisperKit = "whisper_kit"
    static let mlxWhisper = "mlx_whisper"
    static let parakeet = "parakeet"
    static let openaiWhisper = "openai_whisper"

    static func displayName(for engine: String?) -> String {
        guard let engine = engine else { return "" }
        switch engine {
        case appleSpeech: return "Apple Speech"
        case whisperKit: return "WhisperKit"
        case mlxWhisper: return "MLX Whisper"
        case parakeet: return "Parakeet"
        case openaiWhisper: return "Whisper API"
        default: return engine
        }
    }
}
