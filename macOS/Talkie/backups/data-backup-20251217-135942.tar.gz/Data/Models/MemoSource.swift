//
//  MemoSource.swift
//  Talkie
//
//  Represents where a voice memo was recorded
//

import Foundation
import SwiftUI

// MARK: - Memo Source

enum MemoSource: Equatable, Hashable {
    case iPhone(deviceName: String?)
    case watch(deviceName: String?)
    case mac(deviceName: String?)
    case live  // TalkieLive always-on recording
    case unknown

    /// Parse from originDeviceId string
    static func from(originDeviceId: String?) -> MemoSource {
        guard let id = originDeviceId, !id.isEmpty else {
            return .unknown
        }

        // Check prefixes
        if id.hasPrefix("watch-") {
            let name = String(id.dropFirst(6))
            return .watch(deviceName: name.isEmpty ? nil : name)
        }
        if id.hasPrefix("mac-") {
            let name = String(id.dropFirst(4))
            return .mac(deviceName: name.isEmpty ? nil : name)
        }
        if id.hasPrefix("live-") {
            return .live
        }

        // No prefix = iPhone (legacy format)
        return .iPhone(deviceName: nil)
    }

    /// SF Symbol icon
    var icon: String {
        switch self {
        case .iPhone: return "iphone"
        case .watch: return "applewatch"
        case .mac: return "desktopcomputer"
        case .live: return "waveform.circle.fill"
        case .unknown: return "questionmark.circle"
        }
    }

    /// Display name
    var displayName: String {
        switch self {
        case .iPhone: return "iPhone"
        case .watch: return "Watch"
        case .mac(let name):
            if let name = name, !name.isEmpty {
                // Shorten "Arach's MacBook Pro" to just "MacBook Pro"
                let shortened = name
                    .replacingOccurrences(of: "'s ", with: " ")
                    .components(separatedBy: " ")
                    .suffix(2)
                    .joined(separator: " ")
                return shortened.isEmpty ? "Mac" : shortened
            }
            return "Mac"
        case .live: return "Live"
        case .unknown: return "Unknown"
        }
    }

    /// Badge color
    var color: Color {
        switch self {
        case .iPhone: return .blue
        case .watch: return .orange
        case .mac: return .purple
        case .live: return .cyan
        case .unknown: return .secondary
        }
    }
}

// MARK: - Sendable Conformance

extension MemoSource: Sendable {}
