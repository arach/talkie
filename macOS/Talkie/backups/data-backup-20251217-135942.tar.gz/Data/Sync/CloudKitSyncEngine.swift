//
//  CloudKitSyncEngine.swift
//  Talkie
//
//  CloudKit sync engine - Background layer that syncs GRDB ↔ CloudKit
//  Decoupled from views, works silently in background
//

import Foundation
import CloudKit

// MARK: - CloudKit Sync Engine

@MainActor
final class CloudKitSyncEngine: ObservableObject {
    static let shared = CloudKitSyncEngine()

    // MARK: - Published State

    @Published var isSyncing = false
    @Published var lastSyncDate: Date?
    @Published var syncError: Error?

    // MARK: - Dependencies

    private let repository: GRDBRepository
    private let container: CKContainer
    private let database: CKDatabase

    // MARK: - Configuration

    private let recordZoneID = CKRecordZone.ID(zoneName: "TalkieMemos", ownerName: CKCurrentUserDefaultName)
    private var syncTimer: Timer?

    // MARK: - Init

    init(repository: GRDBRepository = GRDBRepository()) {
        self.repository = repository
        self.container = CKContainer(identifier: "iCloud.com.jdi.talkie")
        self.database = container.privateCloudDatabase
    }

    // MARK: - Public API

    /// Start periodic background sync (every 5 minutes)
    func startPeriodicSync() {
        // Initial sync
        Task {
            await performFullSync()
        }

        // Periodic sync
        syncTimer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                await self?.performFullSync()
            }
        }
    }

    /// Stop periodic sync
    func stopPeriodicSync() {
        syncTimer?.invalidate()
        syncTimer = nil
    }

    /// Manual sync trigger
    func sync() async {
        await performFullSync()
    }

    // MARK: - Sync Logic

    private func performFullSync() async {
        guard !isSyncing else {
            print("⏭️ Sync already in progress, skipping...")
            return
        }

        isSyncing = true
        syncError = nil

        do {
            // Step 1: Pull changes from CloudKit
            print("⬇️ Pulling changes from CloudKit...")
            await pullChangesFromCloudKit()

            // Step 2: Push local changes to CloudKit
            print("⬆️ Pushing local changes to CloudKit...")
            await pushChangesToCloudKit()

            lastSyncDate = Date()
            print("✅ Sync complete")

        } catch {
            print("❌ Sync failed: \(error)")
            syncError = error
        }

        isSyncing = false
    }

    // MARK: - Pull Changes from CloudKit

    private func pullChangesFromCloudKit() async {
        do {
            // Fetch all memo records from CloudKit
            let query = CKQuery(recordType: "VoiceMemo", predicate: NSPredicate(value: true))
            query.sortDescriptors = [NSSortDescriptor(key: "modificationDate", ascending: false)]

            let (matchResults, _) = try await database.records(matching: query)

            // Process each record
            for (recordID, result) in matchResults {
                switch result {
                case .success(let record):
                    try await processCloudKitRecord(record)
                case .failure(let error):
                    print("⚠️ Failed to fetch record \(recordID): \(error)")
                }
            }

        } catch {
            print("❌ Pull failed: \(error)")
            throw error
        }
    }

    private func processCloudKitRecord(_ record: CKRecord) async throws {
        // Convert CKRecord → VoiceMemo
        guard let memo = convertRecordToMemo(record) else {
            print("⚠️ Failed to convert record to memo")
            return
        }

        // Check if we have this memo locally
        if let existingMemo = try await repository.fetchMemo(id: memo.id) {
            // Conflict resolution: Use latest based on lastModified
            if memo.lastModified > existingMemo.memo.lastModified {
                print("📥 Updating local memo from CloudKit: \(memo.id)")
                try await repository.saveMemo(memo)
            } else {
                print("⏭️ Local memo is newer, skipping: \(memo.id)")
            }
        } else {
            // New memo from CloudKit
            print("📥 Creating new local memo from CloudKit: \(memo.id)")
            try await repository.saveMemo(memo)
        }
    }

    // MARK: - Push Changes to CloudKit

    private func pushChangesToCloudKit() async {
        do {
            // Fetch memos that need syncing (modified since last sync)
            let memosToSync = try await fetchMemosNeedingSync()

            guard !memosToSync.isEmpty else {
                print("✅ No local changes to push")
                return
            }

            print("📤 Pushing \(memosToSync.count) memos to CloudKit...")

            // Convert to CKRecords and save
            let records = memosToSync.compactMap { convertMemoToRecord($0) }

            // Save in batches (CloudKit limit: 400 records per batch)
            let batchSize = 400
            for batch in records.chunked(into: batchSize) {
                let (saveResults, _) = try await database.modifyRecords(saving: batch, deleting: [])

                // Mark successful saves
                for (recordID, result) in saveResults {
                    switch result {
                    case .success(let record):
                        print("✅ Pushed memo: \(recordID.recordName)")
                        // Update cloudSyncedAt timestamp
                        if let memoID = UUID(uuidString: recordID.recordName),
                           var memo = try await repository.fetchMemo(id: memoID)?.memo {
                            memo.cloudSyncedAt = Date()
                            try await repository.saveMemo(memo)
                        }
                    case .failure(let error):
                        print("❌ Failed to push memo \(recordID): \(error)")
                    }
                }
            }

        } catch {
            print("❌ Push failed: \(error)")
            throw error
        }
    }

    private func fetchMemosNeedingSync() async throws -> [VoiceMemo] {
        // For now, fetch all memos (we'll optimize this later with a "needsSync" flag)
        // In production, you'd track which memos changed since last sync
        let allMemos = try await repository.fetchMemos(
            sortBy: .timestamp,
            ascending: false,
            limit: 10000,  // Fetch all for sync
            offset: 0,
            searchQuery: nil
        )

        // Filter to memos that haven't been synced or modified since last sync
        return allMemos.filter { memo in
            guard let lastSync = lastSyncDate else { return true }  // Never synced
            return memo.lastModified > lastSync
        }
    }

    // MARK: - Conversions

    /// Convert VoiceMemo → CKRecord
    private func convertMemoToRecord(_ memo: VoiceMemo) -> CKRecord {
        let recordID = CKRecord.ID(recordName: memo.id.uuidString, zoneID: recordZoneID)
        let record = CKRecord(recordType: "VoiceMemo", recordID: recordID)

        // Core properties
        record["createdAt"] = memo.createdAt as CKRecordValue
        record["lastModified"] = memo.lastModified as CKRecordValue
        record["title"] = (memo.title ?? "") as CKRecordValue
        record["duration"] = memo.duration as CKRecordValue
        record["sortOrder"] = memo.sortOrder as CKRecordValue

        // Content
        record["transcription"] = (memo.transcription ?? "") as CKRecordValue
        record["notes"] = (memo.notes ?? "") as CKRecordValue
        record["summary"] = (memo.summary ?? "") as CKRecordValue
        record["tasks"] = (memo.tasks ?? "") as CKRecordValue
        record["reminders"] = (memo.reminders ?? "") as CKRecordValue

        // Audio (store as CKAsset)
        if let audioPath = memo.audioFilePath {
            let audioURL = audioStorageURL(for: audioPath)
            if FileManager.default.fileExists(atPath: audioURL.path) {
                let asset = CKAsset(fileURL: audioURL)
                record["audioAsset"] = asset
            }
        }

        // Waveform data
        if let waveform = memo.waveformData {
            record["waveformData"] = waveform as CKRecordValue
        }

        // Processing state
        record["isTranscribing"] = memo.isTranscribing as CKRecordValue
        record["isProcessingSummary"] = memo.isProcessingSummary as CKRecordValue
        record["isProcessingTasks"] = memo.isProcessingTasks as CKRecordValue
        record["isProcessingReminders"] = memo.isProcessingReminders as CKRecordValue
        record["autoProcessed"] = memo.autoProcessed as CKRecordValue

        // Provenance
        record["originDeviceId"] = (memo.originDeviceId ?? "") as CKRecordValue
        if let macReceived = memo.macReceivedAt {
            record["macReceivedAt"] = macReceived as CKRecordValue
        }

        record["pendingWorkflowIds"] = (memo.pendingWorkflowIds ?? "") as CKRecordValue

        return record
    }

    /// Convert CKRecord → VoiceMemo
    private func convertRecordToMemo(_ record: CKRecord) -> VoiceMemo? {
        guard let idString = record.recordID.recordName,
              let id = UUID(uuidString: idString),
              let createdAt = record["createdAt"] as? Date,
              let lastModified = record["lastModified"] as? Date else {
            return nil
        }

        let title = record["title"] as? String
        let duration = record["duration"] as? Double ?? 0
        let sortOrder = record["sortOrder"] as? Int ?? 0

        let transcription = record["transcription"] as? String
        let notes = record["notes"] as? String
        let summary = record["summary"] as? String
        let tasks = record["tasks"] as? String
        let reminders = record["reminders"] as? String

        // Handle audio asset
        var audioFilePath: String?
        if let audioAsset = record["audioAsset"] as? CKAsset,
           let assetURL = audioAsset.fileURL {
            // Download and save audio file
            audioFilePath = saveAudioAsset(assetURL, memoId: id)
        }

        let waveformData = record["waveformData"] as? Data

        let isTranscribing = record["isTranscribing"] as? Bool ?? false
        let isProcessingSummary = record["isProcessingSummary"] as? Bool ?? false
        let isProcessingTasks = record["isProcessingTasks"] as? Bool ?? false
        let isProcessingReminders = record["isProcessingReminders"] as? Bool ?? false
        let autoProcessed = record["autoProcessed"] as? Bool ?? false

        let originDeviceId = record["originDeviceId"] as? String
        let macReceivedAt = record["macReceivedAt"] as? Date
        let pendingWorkflowIds = record["pendingWorkflowIds"] as? String

        return VoiceMemo(
            id: id,
            createdAt: createdAt,
            lastModified: lastModified,
            title: title,
            duration: duration,
            sortOrder: sortOrder,
            transcription: transcription,
            notes: notes,
            summary: summary,
            tasks: tasks,
            reminders: reminders,
            audioFilePath: audioFilePath,
            waveformData: waveformData,
            isTranscribing: isTranscribing,
            isProcessingSummary: isProcessingSummary,
            isProcessingTasks: isProcessingTasks,
            isProcessingReminders: isProcessingReminders,
            autoProcessed: autoProcessed,
            originDeviceId: originDeviceId,
            macReceivedAt: macReceivedAt,
            cloudSyncedAt: Date(),  // Mark as synced
            pendingWorkflowIds: pendingWorkflowIds
        )
    }

    // MARK: - Audio Helpers

    private func audioStorageURL(for relativePath: String) -> URL {
        let appSupport = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        )[0]
        return appSupport
            .appendingPathComponent("Talkie/Audio", isDirectory: true)
            .appendingPathComponent(relativePath)
    }

    private func saveAudioAsset(_ assetURL: URL, memoId: UUID) -> String {
        let fileName = "\(memoId.uuidString).m4a"
        let destinationURL = audioStorageURL(for: fileName)

        // Copy file
        try? FileManager.default.copyItem(at: assetURL, to: destinationURL)

        return fileName
    }
}

// MARK: - Array Extension (Chunking)

extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0..<Swift.min($0 + size, count)])
        }
    }
}
