//
//  GRDBRepository.swift
//  Talkie
//
//  GRDB implementation of MemoRepository
//  Efficient SQLite queries with proper indexing
//

import Foundation
import GRDB

// MARK: - GRDB Repository

actor GRDBRepository: MemoRepository {
    private let dbManager: DatabaseManager

    init(dbManager: DatabaseManager = .shared) {
        self.dbManager = dbManager
    }

    // MARK: - Fetch Memos (The Performance Critical Method)

    func fetchMemos(
        sortBy: MemoSortField,
        ascending: Bool,
        limit: Int,
        offset: Int,
        searchQuery: String? = nil
    ) async throws -> [VoiceMemo] {
        let db = try dbManager.database()

        return try await db.read { db in
            var request = VoiceMemo.all()

            // Apply search filter (uses FTS5 full-text search index)
            if let query = searchQuery, !query.isEmpty {
                // TODO: Implement FTS search
                // For now, use basic LIKE (will add FTS integration later)
                request = request.filter(
                    VoiceMemo.Columns.title.like("%\(query)%") ||
                    VoiceMemo.Columns.transcription.like("%\(query)%")
                )
            }

            // Apply sorting (uses indexes!)
            switch sortBy {
            case .timestamp:
                request = ascending
                    ? request.order(VoiceMemo.Columns.createdAt.asc)
                    : request.order(VoiceMemo.Columns.createdAt.desc)

            case .title:
                // Sort by title, nulls last
                request = ascending
                    ? request.order(VoiceMemo.Columns.title.ascNullsLast)
                    : request.order(VoiceMemo.Columns.title.descNullsFirst)

            case .duration:
                request = ascending
                    ? request.order(VoiceMemo.Columns.duration.asc)
                    : request.order(VoiceMemo.Columns.duration.desc)

            case .workflows:
                // Workflow count requires join - most expensive sort
                // We'll compute this in Swift for now (acceptable for displayed items only)
                // Alternatively: Add a cached workflowCount column updated via triggers
                request = request.order(VoiceMemo.Columns.createdAt.desc)
            }

            // CRITICAL: Apply LIMIT and OFFSET at SQL level
            // This is where the 90% memory savings happen
            request = request.limit(limit, offset: offset)

            // Execute query
            let memos = try request.fetchAll(db)

            // If sorting by workflows, do client-side sort on the limited set
            if sortBy == .workflows {
                // Fetch workflow counts for just these memos
                let memoIds = memos.map(\.id)
                let workflowCounts = try fetchWorkflowCounts(for: memoIds, in: db)

                return memos.sorted { a, b in
                    let countA = workflowCounts[a.id] ?? 0
                    let countB = workflowCounts[b.id] ?? 0
                    return ascending ? countA < countB : countA > countB
                }
            }

            return memos
        }
    }

    // MARK: - Count

    func countMemos(searchQuery: String? = nil) async throws -> Int {
        let db = try dbManager.database()

        return try await db.read { db in
            var request = VoiceMemo.all()

            if let query = searchQuery, !query.isEmpty {
                request = request.filter(
                    VoiceMemo.Columns.title.like("%\(query)%") ||
                    VoiceMemo.Columns.transcription.like("%\(query)%")
                )
            }

            return try request.fetchCount(db)
        }
    }

    // MARK: - Fetch Single Memo with Relationships

    func fetchMemo(id: UUID) async throws -> MemoWithRelationships? {
        let db = try dbManager.database()

        return try await db.read { db in
            // Fetch memo
            guard let memo = try VoiceMemo
                .filter(VoiceMemo.Columns.id == id.uuidString)
                .fetchOne(db) else {
                return nil
            }

            // Fetch relationships
            let transcripts = try TranscriptVersion
                .filter(TranscriptVersion.Columns.memoId == id.uuidString)
                .order(TranscriptVersion.Columns.version.desc)
                .fetchAll(db)

            let workflows = try WorkflowRun
                .filter(WorkflowRun.Columns.memoId == id.uuidString)
                .order(WorkflowRun.Columns.runDate.desc)
                .fetchAll(db)

            return MemoWithRelationships(
                memo: memo,
                transcriptVersions: transcripts,
                workflowRuns: workflows
            )
        }
    }

    // MARK: - Save Operations

    func saveMemo(_ memo: VoiceMemo) async throws {
        let db = try dbManager.database()

        try await db.write { db in
            var mutableMemo = memo
            try mutableMemo.save(db)
        }
    }

    func deleteMemo(id: UUID) async throws {
        let db = try dbManager.database()

        try await db.write { db in
            try VoiceMemo
                .filter(VoiceMemo.Columns.id == id.uuidString)
                .deleteAll(db)
        }
    }

    // MARK: - Relationships

    func fetchTranscriptVersions(for memoId: UUID) async throws -> [TranscriptVersion] {
        let db = try dbManager.database()

        return try await db.read { db in
            try TranscriptVersion
                .filter(TranscriptVersion.Columns.memoId == memoId.uuidString)
                .order(TranscriptVersion.Columns.version.desc)
                .fetchAll(db)
        }
    }

    func fetchWorkflowRuns(for memoId: UUID) async throws -> [WorkflowRun] {
        let db = try dbManager.database()

        return try await db.read { db in
            try WorkflowRun
                .filter(WorkflowRun.Columns.memoId == memoId.uuidString)
                .order(WorkflowRun.Columns.runDate.desc)
                .fetchAll(db)
        }
    }

    func saveTranscriptVersion(_ version: TranscriptVersion) async throws {
        let db = try dbManager.database()

        try await db.write { db in
            var mutableVersion = version
            try mutableVersion.save(db)
        }
    }

    func saveWorkflowRun(_ run: WorkflowRun) async throws {
        let db = try dbManager.database()

        try await db.write { db in
            var mutableRun = run
            try mutableRun.save(db)
        }
    }

    // MARK: - Helper: Fetch Workflow Counts

    private func fetchWorkflowCounts(for memoIds: [UUID], in db: Database) throws -> [UUID: Int] {
        let idStrings = memoIds.map(\.uuidString)

        let rows = try Row.fetchAll(
            db,
            sql: """
                SELECT memoId, COUNT(*) as count
                FROM workflow_runs
                WHERE memoId IN (\(idStrings.map { "?" }.joined(separator: ",")))
                GROUP BY memoId
                """,
            arguments: StatementArguments(idStrings)
        )

        var counts: [UUID: Int] = [:]
        for row in rows {
            if let idString: String = row["memoId"],
               let id = UUID(uuidString: idString),
               let count: Int = row["count"] {
                counts[id] = count
            }
        }

        return counts
    }
}

// MARK: - Column Extensions

private extension Column {
    var ascNullsLast: SQLOrderingTerm {
        asc.sqlExpression.collating(.nocase)
    }

    var descNullsFirst: SQLOrderingTerm {
        desc.sqlExpression.collating(.nocase)
    }
}
